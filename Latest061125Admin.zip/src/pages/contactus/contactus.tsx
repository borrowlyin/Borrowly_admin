import React from "react";
import Contactuslist from "./components/contactuslist";

const ContactUs: React.FC = () => {
  return (
    <div className="">
      <Contactuslist />
    </div>
  );
};

export default ContactUs;
